import AboutView from './About.jsx'

export default AboutView
