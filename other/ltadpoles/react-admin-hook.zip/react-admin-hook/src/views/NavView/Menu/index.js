import MenuView from './Menu.jsx'

export default MenuView
