import FormBaseView from './FormBaseView.jsx'

export default FormBaseView
