import CollapseView from './Collapse.jsx'

export default CollapseView
