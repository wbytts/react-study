import TabsView from './Tabs.jsx'

export default TabsView
