import View500 from './500.jsx'

export default View500
