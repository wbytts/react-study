import DefaultLayout from './DefaultLayout.jsx'

export default DefaultLayout
