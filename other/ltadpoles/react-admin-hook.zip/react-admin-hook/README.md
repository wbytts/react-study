> Hook 版本

移除 `class` 组件，全面拥抱 `hook`

移除了 `Redux` 和 `React-Redux`